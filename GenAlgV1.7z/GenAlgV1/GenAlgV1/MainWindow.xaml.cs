﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using LiveCharts;
using LiveCharts.Wpf;
using System.Threading;

namespace GenAlgV1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        

        public SeriesCollection SeriesCollection { get; set; }
        public string[] Labels { get; set; }
        public Func<double, string> YFormatter { get; set; }

        GenAlgWorck temp = null;
        AnswerClass answer = null;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Start()
        {
            NumIterText.Text = "0";

            string Functon = "";
            // Если выбран ручной ввод функции
            if (ManualFuncRadio.IsChecked == true)
            {
                Functon = ManualFuncText.Text;
            }
            if (SaveFuncRadio.IsChecked == true)
            {
                Functon = SaveFuncCombo.Text;
            }

            List<double> args = new List<double>(); // Аргументы границы/кодирования
            args.Add(Convert.ToDouble(MinText.Text)); args.Add(Convert.ToDouble(MaxText.Text)); // Имеем границы

            // Если целочисленное кодирование
            if (IntCodeCheck.IsChecked == true)
            {
                args.Add(Convert.ToDouble(CountBitText.Text));
            }

            temp = new GenAlgWorck();

            // Если целочисленное кодирование
            if (args.Count == 3)
            {
                temp.SetGr(args);
            }
            else // Если вещественное
            {
                temp.SetGr(args[0], args[1]);
            }

            temp.SetFunc(Functon);

            List<double> argsgen = new List<double>(); // Параметры ГА
            argsgen.Add(Convert.ToDouble(CountPersonText.Text)); // Размер популяции
            argsgen.Add(Convert.ToDouble(CountIterText.Text)); // Количество итераци
            argsgen.Add(Convert.ToDouble(TournirText.Text)); // Турнир
            argsgen.Add(Convert.ToDouble(ChanceCrossText.Text)); // Шанс скрещивания
            argsgen.Add(Convert.ToDouble(ChanceMutationText.Text)); // Шанс мутации
            argsgen.Add(Convert.ToDouble(ChanceInversText.Text)); // Шанс инверсии
            argsgen.Add(Math.Pow(10, Convert.ToDouble(SpikeEps.Text))); // Разность

            // Итераций для вымирания
            if (SpikeCheckBox.IsChecked == true)
            {
                argsgen.Add(Convert.ToDouble(CpikeCount.Text));
            }
            else argsgen.Add(argsgen[0]*2);

            temp.SetAlgPar(argsgen);
            answer = temp.StartWorck();

            NumIterBox.Items.Clear();
            for (int i = 0; i < answer.log.Count; i++)
            {
                NumIterBox.Items.Add(i);
            }
            NumIterBox.SelectedIndex = 0;


            RefreshAnswer();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Start();
            PrintGraph();
        }

        private void RefreshAnswer()
        {
            if (answer != null)
            {
                PointMinText.Text = "(";
                foreach (double t in answer.minPoint)
                {
                    PointMinText.Text += t + "; ";
                }
                PointMinText.Text += ")";

                FuncMinText.Text = Convert.ToString(answer.MinF);

                if ((NumIterText.Text != ""))
                {
                    int index = Convert.ToInt32(NumIterText.Text);
                    answer.log[index].PrintLog((bool)OrderCheck.IsChecked, Convert.ToInt32(AroundText.Text));

                    ArgLogText.Text = "Average: " + answer.log[index].Average + Environment.NewLine;
                    ArgLogText.Text += "Min: " + answer.log[index].MinF + Environment.NewLine;
                    ArgLogText.Text += Environment.NewLine;

                    ArgLogText.Text += answer.log[index].RealLog;

                    CodeLogText.Text = "Average: " + answer.log[index].Average + Environment.NewLine;
                    CodeLogText.Text += "Min: " + answer.log[index].MinF + Environment.NewLine;
                    CodeLogText.Text += Environment.NewLine;
                    CodeLogText.Text += answer.log[index].CodeLog;
                }
            }
        }

        private void OrderCheck_Click(object sender, RoutedEventArgs e)
        {
            RefreshAnswer();
        }

        private void AroundText_TextChanged(object sender, TextChangedEventArgs e)
        {
            if(AroundText.Text!="") RefreshAnswer();
        }

        private void PrintGraph()
        {
            if (answer != null)
            {
                List<double> Min = new List<double>();
                List<double> Average = new List<double>();

                DataContext = null;

                foreach (LogClass k in answer.log)
                {
                    Min.Add(k.MinF);
                    Average.Add(k.Average);
                }

                SeriesCollection = new SeriesCollection();

                if (MinGraphCheck.IsChecked == true)
                {
                    SeriesCollection.Add(new LineSeries
                    {
                        Title = "Min",
                        Values = new ChartValues<double>(Min),
                        PointForeground = Brushes.Gray
                    });
                }

                if (AverageGraphCheck.IsChecked == true)
                {
                    SeriesCollection.Add(new LineSeries
                    {
                        Title = "Average",
                        Values = new ChartValues<double>(Average),
                        PointForeground = Brushes.Orange
                    });
                }

                YFormatter = value => value.ToString();

                DataContext = this;
            }
        }

        private void NumIterText_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                if (NumIterText.Text != "") RefreshAnswer();
            }
            catch (Exception ex)
            {
                NumIterText.Text = "0";
            }
        }

        private void NumIterBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            NumIterText.Text = Convert.ToString(NumIterBox.SelectedIndex);
        }

        private void MinGraphCheck_Click(object sender, RoutedEventArgs e)
        {
            PrintGraph();
        }
    }



}
